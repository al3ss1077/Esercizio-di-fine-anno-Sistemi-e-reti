﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows;

namespace Socket_4I
{
    public partial class MainWindow : Window
    {
        // Socket per la comunicazione UDP
        Socket socket = null;

        // Thread per la ricezione dei messaggi
        Thread receiveThread = null;

        public MainWindow()
        {
            InitializeComponent();

            // Inizializzazione del socket per la comunicazione UDP
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            // Impostazione dell'indirizzo IP locale e della porta
            IPAddress local_address = IPAddress.Any;
            IPEndPoint local_endpoint = new IPEndPoint(local_address, 11000);
            socket.Bind(local_endpoint);

            // Abilitazione delle trasmissioni broadcast
            socket.EnableBroadcast = true;

            // Avvio del thread per la ricezione dei messaggi
            receiveThread = new Thread(ReceiveMessages);
            receiveThread.IsBackground = true;
            receiveThread.Start();
        }

        // Metod eseguito nel thread per la ricezione dei messaggi
        private void ReceiveMessages()
        {
            try
            {
                while (true)
                {
                    // Buffer per memorizzare i dati ricevuti
                    byte[] buffer = new byte[1024];

                    // Endpoint del mittente
                    EndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);

                    // Ricezione dei dati
                    int nBytes = socket.ReceiveFrom(buffer, ref remoteEndPoint);

                    // Estrazione dell'indirizzo IP del mittente
                    string from = ((IPEndPoint)remoteEndPoint).Address.ToString();

                    // Decodifica dei dati ricevuti in una stringa
                    string message = Encoding.UTF8.GetString(buffer, 0, nBytes);

                    // Aggiunta del messaggio alla lista degli elementi UI (richiede Dispatcher.Invoke perché stiamo aggiornando l'interfaccia utente da un thread diverso)
                    Dispatcher.Invoke(() =>
                    {
                        lstMessaggi.Items.Add(from + ": " + message);
                    });
                }
            }
            catch (SocketException ex)
            {
                // Gestione degli errori di socket
                MessageBox.Show(ex.Message);
            }
        }

        // Metod per gestire l'evento di click sul pulsante "Invia"
        private void btnInvia_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Conversione dell'indirizzo IP del destinatario da stringa a IPAddress
                IPAddress remote_address = IPAddress.Parse(txtTo.Text);

                // Creazione dell'endpoint del destinatario
                IPEndPoint remote_endpoint = new IPEndPoint(remote_address, 11000);

                // Conversione del messaggio da stringa a byte array
                byte[] message = Encoding.UTF8.GetBytes(txtMessaggio.Text);

                // Invio del messaggio
                socket.SendTo(message, remote_endpoint);
            }
            catch (FormatException)
            {
                // Gestione dell'errore nel formato dell'indirizzo IP inserito dall'utente
                MessageBox.Show("Indirizzo IP non valido.");
            }
        }
    }
}
